package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Map extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap map;
    List<Model> locationList;
    DatabaseClass databaseClass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        locationList = new ArrayList<>();
        databaseClass = new DatabaseClass(this);
        fetchAllLocationsFromDatabase();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1){
            recreate();
        }
    }

    void fetchAllLocationsFromDatabase()
    {
        Cursor cursor = databaseClass.readAllData();
        if (cursor.getCount() == 0)
        {
            Toast.makeText(this, "No locations to show", Toast.LENGTH_SHORT).show();
        }

        else
        {
            while(cursor.moveToNext())
            {
                locationList.add(new Model(cursor.getString(0),cursor.getString(1),cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5)));
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        List<Address> addressList;
        double doubleLat = 0, doubleLong = 0;
        for (int i = 0; i< 1; i++)
        {
            Geocoder geocoder = new Geocoder(this);
            try {
                addressList = geocoder.getFromLocationName(locationList.get(i).getLocation(), 1);
                if (addressList != null){
                    Address location = addressList.get(i);
                    doubleLat = location.getLatitude();
                    doubleLong = location.getLongitude();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            LatLng tempName = new LatLng(doubleLat, doubleLong);
            map.addMarker((new MarkerOptions().position(tempName)).title(locationList.get(i).getName()));
            map.moveCamera(CameraUpdateFactory.newLatLng(tempName));
        }
    }
}